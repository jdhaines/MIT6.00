# 6.00 Problem Set 3
# Name: Josh Haines
# Collaborators: None
# Time Spent: ~7hrs
# Hangman

# -----------------------------------
# Helper code
# (you don't need to understand this helper code)
import random
import string
import sys

WORDLIST_FILENAME = "words.txt"

def loadWords():
    """
    Returns a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print "Loading word list from file..."
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r', 0)
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = string.split(line)
    print "  ", len(wordlist), "words loaded."
    return wordlist

def chooseWord(wordlist):
    """
    wordlist (list): list of words (strings)

    Returns a word from wordlist at random
    """
    return random.choice(wordlist)

# end of helper code
# -----------------------------------
def updateBlankList(list, position, letter):
    """
    Take in the blank list.  Update the list by adding any of the 
    new letters to it which were correct.  

    Update the location in "list" indicated by "position" with the "letter".
    Send back the list when finished.
    """
    list[position] = letter
    return list

def play():
    """
    Start function starts the game.  No Inputs, no outputs except printing.
    We'll allow the player to "play again" or quit."

    First we will load in a list of words and choose one of them.

    Then we'll use a function (blankList) which will update and return 
    a correct blank list for our game (something like _ _ e _ _).

    We'll start off a loop that cycles down the number of guesses if wrong,
    and doesn't if right.
    """
    #variable
    numGuessesLeft = 8  # number of guesses per game
    alphabetLeft = "abcdefghijklmnopqrstuvwxyz"  # starting alphabet
    #blankList = bytearray(str)  # _ _ e _ _ variable

    # Get a word
    # actually load the dictionary of words and point to it with 
    # the wordlist variable so that it can be accessed from anywhere
    # in the program
    #wordlist = loadWords()
    wordList = loadWords()
    word = chooseWord(wordList)
    word = list(word)
    blankList = list(word)

    #generate blankList
    for i in range(len(word)):
        blankList[i] = "_"

    # Opening game text
    print "Welcome to the game, Hangman!"
    print "I am thinking of a word that is %d letters long." % len(word)

    # Start Game
    while numGuessesLeft > 0:
        wrongGuess = 0
        print "--------------------"
        print "You have %d guesses left." % numGuessesLeft
        print "Available Letters: %s" % alphabetLeft
        letterGuess = raw_input("Please guess a letter: ")
        alphabetLeft = alphabetLeft.replace(letterGuess,"")
        for ii in range(len(word)):
            if word[ii] == letterGuess:
                blankList = updateBlankList(blankList, ii, letterGuess)
            else:
                wrongGuess += 1  
        if wrongGuess < len(word):
            print "Good Job: %s" % " ".join(blankList)
        else:
            print "Oops! That letter is not in my word: %s" % " ".join(blankList)
            numGuessesLeft += -1
        if "_" not in blankList:
            return "won"
    if "_" in blankList:
        print "The word was %s." % " ".join(word)
        return "lost"
    else:
        return "won"

def start():
    playAgain = "y"

    while playAgain == "y":
        outcome = play()
        if outcome == "lost":
            print "Game Over, You Lost."
        elif outcome == "won":
            print "Congratulations, You Won!"
        else:
            sys.exit("Houston, we have a problem...")
        playAgain = raw_input("Do you want to play again? y or n ")
    sys.exit("Thanks for playing!")

start()
# end

# notes
# actually load the dictionary of words and point to it with 
# the wordlist variable so that it can be accessed from anywhere
# in the program
# use slicing, .find, 
# var = 'abc'
# var[0] = 'a'
# var[0:1] = 'a'
# var[0:2] = 'ab'
# var.find('b') = 1